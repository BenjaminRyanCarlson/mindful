import 'package:flutter/material.dart';


void main() => runApp(MyApp());

/// This Widget is the main application widget.
class MyApp extends StatelessWidget {
  static const String _title = 'Meditate';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: MyStatelessWidget(),
      ),
    );
  }
}

/// This is the stateless widget that the main application instantiates.
class MyStatelessWidget extends StatelessWidget {
  MyStatelessWidget({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
        const RaisedButton(
        onPressed:(
    class Countdown extends MyStatelessWidget{
    final Widget child;

    Clock({this.child});

    GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
    Duration _duration = Duration(minutes:5);

    @override
    Widget build(BuildContext context) {
    return Scaffold(
    key: _scaffoldKey,
    appBar: AppBar(title: Text(widget.title)),
    body: Center(
    child: Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.center,
    mainAxisAlignment: MainAxisAlignment.center,
    children: <Widget>[
    Text('Slide direction Up'),
    SlideCountdownClock(
    duration: Duration(days: 20, minutes: 1000000),
    slideDirection: SlideDirection.Up,
    separator: ":",
    textStyle: TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    ),
    shouldShowDay: true,
    onDone: () {
    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Clock 1 finished')));
    },
    ),
    _buildSpace(),
    Text('Slide direction Down'),
    SlideCountdownClock(
    duration: _duration,
    slideDirection: SlideDirection.Down,
    separator: ":",
    textStyle: TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    ),
    onDone: () {
    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Clock 1 finished')));
    },
    ),
    _buildSpace(),
    Text('Use box Decoration'),
    Padding(
    padding: EdgeInsets.all(10),
    child: SlideCountdownClock(
    duration: _duration,
    slideDirection: SlideDirection.Up,
    separator: "-",
    textStyle: TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    color: Colors.white,
    ),
    separatorTextStyle: TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    color: Colors.blue,
    ),
    padding: EdgeInsets.all(10),
    decoration: BoxDecoration(color: Colors.blue, shape: BoxShape.circle),
    onDone: () {
    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Clock 1 finished')));
    };
    ),},
        child: Text('Start Breathing', style: TextStyle(fontSize: 20)),
    )
    ]
    )) ;
}
}